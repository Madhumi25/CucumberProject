package com.practiceautomation.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.excelutility.excel.ExcelUtility;
import com.practiceautomation.pages.HTMLCategoryPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
public class HTMLCategorySteps 
{
	WebDriver driver;
	HTMLCategoryPage html;
	ExcelUtility excel = new ExcelUtility();
	
	@Given("^To Launch the browser$")
	public void to_Launch_the_browser() throws Throwable 
	{
		html = new HTMLCategoryPage(driver);
		html.launchBrowser("firefox");
	}

	@When("^To open the Practice automation website$")
	public void to_open_the_Practice_automation_website() throws Throwable 
	{
		html.openWebsite();
	}

	@Then("^Enter Email and password in login field$")
	public void enter_Email_and_password_in_login_field() throws Throwable 
	{
	    	html.loginDetails(excel.username(2),excel.password(2));
	}

	@Then("^Click on the Login Button$")
	public void click_on_the_Login_Button() throws Throwable 
	{
	    	html.clickLoginButton();
	}

	@Then("^Click Shop icon, Click HTML and buy the book$")
	public int click_Shop_icon_Click_HTML_and_buy_the_book() throws Throwable 
	{
		Thread.sleep(2000);
		int actual=html.htmlBookCategory();
		System.out.println("Total number of HTML books Available: "+actual);			//Only 3 books will be available
		int expected = 3;
		Assert.assertEquals(expected, actual);			//assert condition get pass
		return actual;
	}

	@And("^View the cart html book$")
	public void view_the_cart_html_book() throws Throwable 
	{
		html.viewCartHtml();
	}
}
